The Dusty-Evolved-Star-Kit
======================================

.. toctree::
   :maxdepth: 2
   :caption: Installation:

   readme
   installation


.. toctree::
   :maxdepth: 2
   :caption: User Documentation:

   usage
   grids
   modules
   contributing
   history

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
