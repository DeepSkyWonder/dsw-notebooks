desk.probabilities package
==========================

Submodules
----------

desk.probabilities.compute\_grid\_weights module
------------------------------------------------

.. automodule:: desk.probabilities.compute_grid_weights
   :members:
   :undoc-members:
   :show-inheritance:

desk.probabilities.create\_pdf module
-------------------------------------

.. automodule:: desk.probabilities.create_pdf
   :members:
   :undoc-members:
   :show-inheritance:

desk.probabilities.create\_prior module
---------------------------------------

.. automodule:: desk.probabilities.create_prior
   :members:
   :undoc-members:
   :show-inheritance:

desk.probabilities.resample\_prior\_to\_model\_grid module
----------------------------------------------------------

.. automodule:: desk.probabilities.resample_prior_to_model_grid
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: desk.probabilities
   :members:
   :undoc-members:
   :show-inheritance:
