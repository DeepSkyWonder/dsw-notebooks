desk package
============

Subpackages
-----------

.. toctree::

   desk.fitting
   desk.outputs
   desk.probabilities
   desk.set_up

Submodules
----------

desk.console\_commands module
-----------------------------

.. automodule:: desk.console_commands
   :members:
   :undoc-members:
   :show-inheritance:

desk.main module
----------------

.. automodule:: desk.main
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: desk
   :members:
   :undoc-members:
   :show-inheritance:
