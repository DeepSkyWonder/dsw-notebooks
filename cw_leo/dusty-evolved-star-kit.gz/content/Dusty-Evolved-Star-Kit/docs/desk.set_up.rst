desk.set\_up package
====================

Submodules
----------

desk.set\_up.config module
--------------------------

.. automodule:: desk.set_up.config
   :members:
   :undoc-members:
   :show-inheritance:

desk.set\_up.create\_output\_files module
-----------------------------------------

.. automodule:: desk.set_up.create_output_files
   :members:
   :undoc-members:
   :show-inheritance:

desk.set\_up.error\_messages module
-----------------------------------

.. automodule:: desk.set_up.error_messages
   :members:
   :undoc-members:
   :show-inheritance:

desk.set\_up.full\_grid module
------------------------------

.. automodule:: desk.set_up.full_grid
   :members:
   :undoc-members:
   :show-inheritance:

desk.set\_up.get\_data module
-----------------------------

.. automodule:: desk.set_up.get_data
   :members:
   :undoc-members:
   :show-inheritance:

desk.set\_up.get\_inputs module
-------------------------------

.. automodule:: desk.set_up.get_inputs
   :members:
   :undoc-members:
   :show-inheritance:

desk.set\_up.get\_models module
-------------------------------

.. automodule:: desk.set_up.get_models
   :members:
   :undoc-members:
   :show-inheritance:

desk.set\_up.scale\_dusty module
--------------------------------

.. automodule:: desk.set_up.scale_dusty
   :members:
   :undoc-members:
   :show-inheritance:

desk.set\_up.scale\_external module
-----------------------------------

.. automodule:: desk.set_up.scale_external
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: desk.set_up
   :members:
   :undoc-members:
   :show-inheritance:
