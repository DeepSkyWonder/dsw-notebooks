desk.fitting package
====================

Submodules
----------

desk.fitting.dusty\_fit module
------------------------------

.. automodule:: desk.fitting.dusty_fit
   :members:
   :undoc-members:
   :show-inheritance:

desk.fitting.fitting\_tools module
----------------------------------

.. automodule:: desk.fitting.fitting_tools
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: desk.fitting
   :members:
   :undoc-members:
   :show-inheritance:
