=======
History
=======

1.7.2 (2020-08-05)

Updates plots with now 17 source maximum for single SED figure. The sed and
sed_indivscripts now use a common set of functions to minimize duplicated code,
and ensure consistency. 


1.7.1 (2020-08-05)

Minor bug fixes to the data retrieval script.


1.7.0 (2020-07-24)

First major release of least-squares fitting DESK. The package is stable with
pytest testing through Github-actions (Ubuntu and OSX: Python 3.6, 3.7, 3.8),
documentation with Sphinx on readthedocs, coverage with codecov,
code quality checks with codacy, installation with pip, and hosted on Github.
Model grids are downloaded using direct-download links on Box.

1.3.1 (2019-04-29)
------------------

* First release on PyPI.
